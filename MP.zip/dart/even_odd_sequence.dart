void main() {
  print("Even Numbers:");
  for (int i = 2; i <= 20; i += 2) {
    print(i);
  }

  print("\nOdd Numbers:");
  for (int i = 1; i <= 19; i += 2) {
    print(i);
  }
}
